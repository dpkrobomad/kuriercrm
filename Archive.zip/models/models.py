
from odoo import models, fields, api


class SaleOrder(models.Model):
    _inherit = 'sale.order'
    
    company = fields.Char('Company Name')
    ts = fields.Char('Shipemnt Type')
    st = fields.Char('Shipemnt Terms')
    
    typeOfShipment = fields.Many2one('site_settings.shipment_type',string="Type Of Shipment")
    shipmentTerms = fields.Many2one('site_settings.terms_of_shipment',string="Shipment Terms")
    cargoReadyDate = fields.Date('Cargo Ready Date')
    originAirport = fields.Char('Origin Airport')
    originCountry = fields.Char('Origin Country')
    destinationCountry = fields.Char('Destination Country')
    commodityType = fields.Char('Commodity Type')
    originZip = fields.Char('Origin Zip')
    originAddress = fields.Char('Origin Address')
    destinationZip = fields.Char('Destination Zip')
    destinationAddress = fields.Char('Destination Address')
    originSeaPort = fields.Char('Origin Sea Port')
    destSeaPort = fields.Char('Destination Sea Port')
    cargoWeight = fields.Char('Cargo Weight')
    product_line_ids = fields.One2many('deepu.sale.order.line','sale_order_id')
    container_line_ids = fields.One2many('deepu.sale.container.line','sale_container_order_id')
    totalChargableWeight = fields.Char('Total Chargable Weight',compute="_compute_TotalChargable")

    @api.onchange('typeOfShipment')
    def _onchange_typeOfShipment(self):
        if self.typeOfShipment:
            self.ts = self.typeOfShipment.name
            
    @api.onchange('shipmentTerms')
    def _onchange_shipmentTerms(self):
        if self.shipmentTerms:
            self.st = self.shipmentTerms.name
            

    
    @api.depends('product_line_ids')
    def _compute_TotalChargable(self):
        print(self.product_line_ids,'>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>')
        vals = 0.0
        if self.ts!='Sea Freight':
            for product in self.product_line_ids:
                
                if product.volume or product.cbm:
                    print(product,product.volume,product.cbm,'$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$')
                    vals += float(product.chargableWeight)
                    print(vals,'**************************************')
            self.totalChargableWeight = vals
        else:
            self.totalChargableWeight = None
                

      



class SaleProductOrder(models.Model):
    _name = 'deepu.sale.order.line'
    sale_order_id = fields.Many2one('sale.order')
    length = fields.Char('Length')
    width = fields.Char('Width')
    height = fields.Char('Height')
    totalpcs = fields.Char('Total pcs')
    grossWeight = fields.Char('Gross Weight')
    cbm = fields.Char('Cbm')
    volume = fields.Char(string='Volume',compute='_compute_weight')
    chargableWeight = fields.Char(string='Chargable Weight',compute='_compute_chargable')
    
    
    @api.depends('length','width','height','totalpcs')
    def _compute_weight(self):
        for item in self:
            print(item,'self *************************************')
            if item.sale_order_id.ts=='Air Freight' and item.length  and item.width  and item.height  and item.totalpcs    :
                print(item.sale_order_id.ts,item.width,item.totalpcs,item.length,item.height)
                val = float(item.length)*float(item.width)*float(item.height)*float(item.totalpcs)
                print(val)
                item.volume = round((val/6000),2)
            elif item.sale_order_id.ts=='LCL' and item.length  and item.width  and item.height  and item.totalpcs    :
                print(item.sale_order_id.ts,item.width,item.totalpcs,item.length,item.height)
                val = float(item.length)*float(item.width)*float(item.height)*float(item.totalpcs)
                print(val)
                item.cbm = round((val/1000000),2)
                item.volume = ''
        
            elif item.sale_order_id.ts=='Courier Service' and item.length  and item.width  and item.height  and item.totalpcs   :
                val = float(item.length)*float(item.width)*float(item.height)*float(item.totalpcs)
                print(val)
                item.volume = round((val/5000),2)
            else:
                item.volume =None
            
    @api.depends('grossWeight','cbm','volume')
    def _compute_chargable(self):
        for item in self:
            try:
                if item.sale_order_id.ts=='Air Freight' or item.sale_order_id.ts=='Courier Service' or item.sale_order_id.ts=='Road Freight' and item.volume is not None and item.grossWeight is not None:
                    if float(item.grossWeight) > float(item.volume):
                        item.chargableWeight = item.grossWeight
                    else:
                            item.chargableWeight = item.volume
                
                elif item.sale_order_id.ts=='LCL' and item.cbm is not None and item.grossWeight is not None:
                    gwcbm = float(item.grossWeight)
                    print(gwcbm)
                    gwcbm = gwcbm/1000
                    gwcbm = round(gwcbm,2)
                    if gwcbm > float(item.cbm):
                        item.chargableWeight = gwcbm
                    else:
                        item.chargableWeight = item.cbm
                else:
                    item.chargableWeight = None
                
            except Exception as e:
                print(e)
            
   
class Containers(models.Model):
    _name = 'deepu.sale.container.line'
    
    sale_container_order_id = fields.Many2one('sale.order')
    typeOfContainer = fields.Char('Type of Container')
    noOfContainers = fields.Char('No. of Containers')
    
    






