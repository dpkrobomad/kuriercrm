# -*- coding: utf-8 -*-
from odoo import http
import json
from odoo.http import request
import ast

class DeepuSaleController(http.Controller):
    @http.route('/get/kuriervogel/order/',type='http',csrf=False,auth="public")
    def getSaleOrder(self,**post):
        print(post)
        name = post['name']
        email = post['email']
        phone = post['phone']
        originCountry = post['originCountry']
        destinationCountry = post['destinationCountry']
        company = post['company']
        ts = request.env['site_settings.shipment_type']
        tsid = ts.sudo().search([('name','=',post['typeOfShipment'])])
        typeOfShipment = tsid.id
        st = request.env['site_settings.terms_of_shipment']
        stid = st.sudo().search([('name','=',post['shipmentTerms'])])
        shipmentTerms = stid.id
        cargoReadyDate = post['cargoReadyDate'] if post['cargoReadyDate'] else None
        commodityType = post['commodityType']
        originAirport = post['originAirport']
        originZip = post['originZip']
        originAddress = post['originAddress']
        destinationZip = post['destinationZip']
        destinationAddress = post['destinationAddress']
        originSeaPort = post['originSeaPort']
        destSeaPort = post['destSeaPort']
        typeOfContainer = post['typeOfContainer']
        noOfContainers = post['noOfContainers']
        cargoWeight = post['cargoWeight']
        items = post['items']
        items= items.replace('\'','')
        print(items)
        items_list = ast.literal_eval(items)
        user_obj = request.env['res.users']
        sale_obj = request.env['sale.order']
        user = user_obj.sudo().search([('email','=',email)])
        print('Searching partner',user,user.partner_id.id,user.partner_id.name)
        if user:
            print(user.partner_id.name)
        else:
            vals = {
            'name' : name,
            'email': email,
            'phone':phone,
            'login':email

            }
            user = user_obj.sudo().create(vals)
            print('new partner created',user.name)
        salesvals = {
        'ts':post['typeOfShipment'],
        'st':post['shipmentTerms'],
        'state':'draft',
        'partner_id' : user.partner_id.id,
        'company':company,
        'typeOfShipment' : typeOfShipment,
        'shipmentTerms' : shipmentTerms,
        'cargoReadyDate' : cargoReadyDate,
        'originAirport' : originAirport,
        'originCountry' : originCountry,
        'destinationCountry' : destinationCountry,
        'commodityType' : commodityType,
        'originZip' : originZip,
        'originAddress' : originAddress,
        'destinationZip' : destinationZip,
        'destinationAddress' : destinationAddress,
        'originSeaPort' : originSeaPort,
        'destSeaPort' : destSeaPort,
        'cargoWeight' : cargoWeight,
        
        }
        sale_order = sale_obj.sudo().create(salesvals)
        
        itemTotalWeight = 0
        itemTotalGW = 0 
        if post['typeOfShipment']=='Air Freight':
            print('air')
            for item in items_list:
                volume = float(item['volume'])
                gW = float(item['grossWeight'])
                itemTotalWeight+= volume
                itemTotalGW += gW
                cGW = gW/167
                print(cGW,'CGWWWWWWWWWWWWWWWWWW')
                chargableWeight = volume if volume > cGW else cGW 
                cargo_obj = request.env['deepu.sale.order.line']
                cargoVals = {
                    'sale_order_id':sale_order.id,
                    'length':item['length'],
                    'width':item['width'],
                    'height':item['height'],
                    'totalpcs':item['totalpcs'],
                    'grossWeight':item['grossWeight'],
                }
                newCargo = cargo_obj.sudo().create(cargoVals)
                print(newCargo,'>>>>>>>>>>>>>>>>>>>>>>>>>')

           
        elif post['typeOfShipment']=='Sea Freight':
            print('sea')
            
        elif post['typeOfShipment']=='LCL':
            print('LCL')
            for item in items_list:
                itemTotalWeight+= float(item['cbm'])
                itemTotalGW += float(item['grossWeight'])
            chargableWeight = 0 
            cargo_obj = request.env['deepu.sale.order.line']
            cargoVals = {
                'sale_order_id':sale_order.id,
                'length':item['length'],
                'width':item['width'],
                'height':item['height'],
                'totalpcs':item['totalpcs'],
                'grossWeight':item['grossWeight'],
            }
            newCargo = cargo_obj.sudo().create(cargoVals)
        elif post['typeOfShipment']=='Road Freight':
            print('Road Freight')
            for item in items_list:
                itemTotalWeight+= float(item['volume'])
                itemTotalGW += float(item['grossWeight'])
                cargoVals = {
                'sale_order_id':sale_order.id,
                'length':item['length'],
                'width':item['width'],
                'height':item['height'],
                'totalpcs':item['totalpcs'],
                'grossWeight':item['grossWeight'],
            }
            newCargo = cargo_obj.sudo().create(cargoVals)
        elif post['typeOfShipment']=='Courier Service':
            print('Courier Service')
            for item in items_list:
                itemTotalWeight+= float(item['volume'])
                itemTotalGW += float(item['grossWeight'])
                cargoVals = {
                'sale_order_id':sale_order.id,
                'length':item['length'],
                'width':item['width'],
                'height':item['height'],
                'totalpcs':item['totalpcs'],
                'grossWeight':item['grossWeight'],
            }
            newCargo = cargo_obj.sudo().create(cargoVals)
        
        print(itemTotalWeight, itemTotalGW,'****************************************************************')
        print('>>>>>>>>>>>>>>>>>>>>')

        
        
        

        
        
        
        
        
        
        
        
        
        
        
        
